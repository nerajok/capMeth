exports.url = `mongodb+srv://neraj:neraj@cluster0-brbg7.mongodb.net/test?retryWrites=true&w=majority`
