
	// const { ChainId, Fetcher, WETH, Route, Trade, TokenAmount, TradeType, Percent } = require('@uniswap/sdk');




	$(document).ready(function (){

    	function uploadHandler(e) {
    		// NEW
        e.preventDefault();
    		$.ajax(
    			'/api/upload',{
    				method: 'post',
    				success: successfulUploadHandler,
					data: {buy: e.target.value,buyamt: e.target.value,sellamt: e.target.value,sell: e.target.value,slip: e.target.value,deadline: e.target.value,dex: e.target.value},
    		},
    		)
		}
		
		document.getElementById("buyamt").onkeyup = function() {

			import ChainId from '@uniswap/sdk';
			import Fetcher from '@uniswap/sdk';
			import WETH from '@uniswap/sdk';
			import Route from '@uniswap/sdk';
			import Trade from '@uniswap/sdk';
			import TokenAmount from '@uniswap/sdk';
			import TradeType from '@uniswap/sdk';
			// const ethers = require('ethers');

			const chainId = ChainId.MAINNET;
			const tokenAddress = '0x6B175474E89094C44Da98b954EedeAC495271d0F';

			const init = async () => {
			const dai = await Fetcher.fetchTokenData(chainId, tokenAddress);
			const weth = WETH[chainId];
			const pair = await Fetcher.fetchPairData(dai, weth);
			const route = new Route([pair], weth);
			const trade = new Trade(route, new TokenAmount(weth, this.value), TradeType.EXACT_INPUT);
			// console.log(route.midPrice.toSignificant(6));
			//   console.log(route.midPrice.invert().toSignificant(6));
			console.log(trade.executionPrice.toSignificant(6));
			const output = await trade.executionPrice.toSignificant(6);
			document.getElementById("sellamt").value = output;   
		 }
		}


    })
