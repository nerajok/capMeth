exports.url = `mongodb+srv://DeadPrez001:zakariya@zakscluster0-3rxf3.azure.mongodb.net/BlockBookUpdate?retryWrites=true&w=majority`
